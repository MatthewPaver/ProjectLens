"""
Test suite for ProjectLens

This package contains unit tests for all components of the ProjectLens system
""" 
